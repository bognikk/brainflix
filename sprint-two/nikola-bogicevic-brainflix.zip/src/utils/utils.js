export const BASE_URL = "https://project-2-api.herokuapp.com";
export const API_KEY = "?api_key=143d6ad4-9a4b-4f49-b55f-82f5ed177fae";
