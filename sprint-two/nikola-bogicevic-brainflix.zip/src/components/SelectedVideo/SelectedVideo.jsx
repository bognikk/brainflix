import "../SelectedVideo/SelectedVideo.scss";

const SelectedVideo = (props) => {
  return <section className="selectedVideo">{props.children}</section>;
};
export default SelectedVideo;
