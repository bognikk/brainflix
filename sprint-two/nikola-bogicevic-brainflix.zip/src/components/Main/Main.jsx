import "../Main/Main.scss";

const Main = (props) => {
  return <section className="main">{props.children}</section>;
};
export default Main;
